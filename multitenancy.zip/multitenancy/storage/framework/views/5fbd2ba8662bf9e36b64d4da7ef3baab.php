<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="max-w-2xl mx-auto p-6 bg-white rounded shadow">
    <h2 class="text-xl font-bold mb-4">Select Roles for Your Hospital</h2>

    <form method="POST" action="<?php echo e(route('tenant.roles.store')); ?>">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3">
                <label class="inline-flex items-center">
                    <input type="checkbox" name="roles[]" value="<?php echo e($template->id); ?>" class="mr-2">
                    <span class="font-semibold"><?php echo e($template->name); ?></span>
                </label>
                <div class="ml-6 text-sm text-gray-600">
                    Permissions: <?php echo e($template->permissions->pluck('name')->join(', ')); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button class="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Save and Continue
        </button>
    </form>
</div>
</body>
</html><?php /**PATH /home/msa/tenancy/multitenancy/resources/views/tenant/select-roles.blade.php ENDPATH**/ ?>