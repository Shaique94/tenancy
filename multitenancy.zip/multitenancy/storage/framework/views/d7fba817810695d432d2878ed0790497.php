<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="<?php echo e(route('tenant.register.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Name">
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <input type="password" name="password_confirmation" placeholder="Confirm Password">
        <button type="submit">Register</button>
    </form>
</body>
</html><?php /**PATH /home/msa/tenancy/multitenancy/resources/views/tenant/auth/register.blade.php ENDPATH**/ ?>