<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="POST" action="<?php echo e(route('tenant.login.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <button type="submit">Login</button>
    </form>
</body>
</html><?php /**PATH /home/msa/tenancy/multitenancy/resources/views/tenant/auth/login.blade.php ENDPATH**/ ?>