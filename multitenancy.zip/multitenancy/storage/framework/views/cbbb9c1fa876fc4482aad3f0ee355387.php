<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h3><?php echo e(auth()->user()->name); ?></h3>
    <h3><?php echo e(auth()->user()->email); ?></h3>
    <form method="POST" action="<?php echo e(route('tenant.logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>

    <a href="<?php echo e(route('tenant.roles.select')); ?>">
        <button type="submit">roles addon</button>
    </a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create appointments')): ?>
        <button>shaique</button>
    <?php endif; ?>
</body>

</html><?php /**PATH /home/msa/tenancy/multitenancy/resources/views/tenant/dashboard.blade.php ENDPATH**/ ?>