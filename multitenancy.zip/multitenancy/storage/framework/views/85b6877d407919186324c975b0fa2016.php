<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Document</title>
</head>
<body>

<div class="max-w-4xl mx-auto mt-10">
    <div class="bg-white shadow rounded-lg p-6">
        <h2 class="text-2xl font-semibold mb-4">Edit Role: <?php echo e($role->name); ?></h2>

        <form method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1" for="name">Role Name</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $role->name)); ?>"
                       class="w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">Permissions</label>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center">
                            <input
                                type="checkbox"
                                name="permissions[]"
                                value="<?php echo e($permission->id); ?>"
                                id="perm_<?php echo e($permission->id); ?>"
                                class="h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                <?php echo e($role->permissions->contains($permission->id) ? 'checked' : ''); ?>

                            >
                            <label for="perm_<?php echo e($permission->id); ?>" class="ml-2 text-sm text-gray-700">
                                <?php echo e($permission->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="flex justify-between items-center">
                <a href="<?php echo e(route('roles.index')); ?>" class="text-sm text-gray-600 hover:underline">← Back to roles</a>
                <button type="submit"
                        class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                    Update Role
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html><?php /**PATH /home/msa/tenancy/multitenancy/resources/views/tenant/roles/edit.blade.php ENDPATH**/ ?>